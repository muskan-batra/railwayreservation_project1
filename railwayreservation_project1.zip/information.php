<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <link rel="stylesheet"  type="text/css" href="muskan_css.css">
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>




    <div class="header_block" style="width:1515px;">
      <div class="innerHeader" >
      <h1 style="color:white; font-family: monospace; vertical-align:middle;">RAILWAY TICKET <span style="color:skyblue;">RESERVATION</span><span style="color:white; font-family: monospace; vertical-align:middle; margin-left:300px;">information</span></h1>
      </div>
    </div>



    <div class="sideBlock">

    <div class="profilePic">
      <img src="admin-png-7.png" alt="">
      <h1>Profile</h1>

    </div>


    <div >
      <ul class="navigator">


        <a href="http://localhost/myproject/muskan_project.php"><li>Home</li></a>
        <br>
        <a   href="http://localhost/myproject/booking_muskan.php"><li>Booking</li></a>
        <br>
        <a href="http://localhost/myproject/information.php"><li>information</li></a>
        <br>
        <a   href="http://localhost/myproject/Reservation%20(1).php"><li>Your Reservation</li></a>
      </ul>
    </div>

    </div>

    <div style="display:block; background-color:#22242A;   margin-left:300px; border-radius:10px;">
      <div style=" padding: 30px; margin-top:100px; font-size:20px; color:white;">
        <?php include 'txt.php'; ?>
      </div>

    </div>


  </body>
</html>
